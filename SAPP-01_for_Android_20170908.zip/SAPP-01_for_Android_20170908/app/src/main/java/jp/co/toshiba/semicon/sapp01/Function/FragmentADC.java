/**
 * COPYRIGHT (C) 2017
 * TOSHIBA CORPORATION STORAGE & ELECTRONIC DEVICES SOLUTIONS COMPANY
 * ALL RIGHTS RESERVED
 *
 * THE SOURCE CODE AND ITS RELATED DOCUMENTATION IS PROVIDED "AS IS". TOSHIBA
 * CORPORATION MAKES NO OTHER WARRANTY OF ANY KIND, WHETHER EXPRESS, IMPLIED OR,
 * STATUTORY AND DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF MERCHANTABILITY,
 * SATISFACTORY QUALITY, NON INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE SOURCE CODE AND DOCUMENTATION MAY INCLUDE ERRORS. TOSHIBA CORPORATION
 * RESERVES THE RIGHT TO INCORPORATE MODIFICATIONS TO THE SOURCE CODE IN LATER
 * REVISIONS OF IT, AND TO MAKE IMPROVEMENTS OR CHANGES IN THE DOCUMENTATION OR
 * THE PRODUCTS OR TECHNOLOGIES DESCRIBED THEREIN AT ANY TIME.
 *
 * TOSHIBA CORPORATION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
 * CONSEQUENTIAL DAMAGE OR LIABILITY ARISING FROM YOUR USE OF THE SOURCE CODE OR
 * ANY DOCUMENTATION, INCLUDING BUT NOT LIMITED TO, LOST REVENUES, DATA OR
 * PROFITS, DAMAGES OF ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL NATURE, PUNITIVE
 * DAMAGES, LOSS OF PROPERTY OR LOSS OF PROFITS ARISING OUT OF OR IN CONNECTION
 * WITH THIS AGREEMENT, OR BEING UNUSABLE, EVEN IF ADVISED OF THE POSSIBILITY OR
 * PROBABILITY OF SUCH DAMAGES AND WHETHER A CLAIM FOR SUCH DAMAGE IS BASED UPON
 * WARRANTY, CONTRACT, TORT, NEGLIGENCE OR OTHERWISE.
 */

package jp.co.toshiba.semicon.sapp01.Function;

import android.annotation.*;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.os.*;
import android.support.v4.app.Fragment;
import android.view.*;
import android.widget.*;

import java.util.*;

import jp.co.toshiba.semicon.sapp01.BLE.*;
import jp.co.toshiba.semicon.sapp01.Main.*;
import jp.co.toshiba.semicon.sapp01.*;

import static jp.co.toshiba.semicon.sapp01.BLE.BleServiceConstants.*;


public class FragmentADC extends Fragment {

    public static FragmentADC newInstance(int sectionNumber) {
        FragmentADC fragment = new FragmentADC();
        Bundle args = new Bundle();
        args.putInt(MainActivity.ARG_SECTION_NUM, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    public FragmentADC() {
    }

    private Callbacks mCallbacks;
    private ToggleButton mTglBtnNotify;
    private TextView mTxtVwReadBatteryValue;
    private TextView mTxtVwNotifyTimeStamp;
    private TextView mTxtVwReadHumidityValue;
    private TextView mTxtVwReadPressureValue1;
    private TextView mTxtVwReadPressureValue2;
    private TextView mTxtVwReadPressureValue3;
    private TextView mTxtVwReadPressureValue4;
    private TextView mTxtVwReadPressureValue5;
    private TextView mTxtVwReadPressureValue6;
    private TextView mTxtVwReadTempValue1;
    private TextView mTxtVwReadTempValue2;
    private boolean mIsNotifyON;

    public interface Callbacks {
        void cbAppendLog(String text);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) return;
        if (!(activity instanceof Callbacks)) {
            throw new ClassCastException("activity does not implemented Callbacks");
        }
        else {
            mCallbacks = ((Callbacks) activity);
        }
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (!(context instanceof Callbacks)) {
            throw new ClassCastException("activity does not implemented Callbacks");
        }
        else {
            mCallbacks = ((Callbacks) context);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mIsNotifyON = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_adc, container, false);

        mTglBtnNotify = (ToggleButton)rootView.findViewById(R.id.toggleNotifyTemp);
        mTxtVwReadBatteryValue = (TextView)rootView.findViewById(R.id.txtVw_NotifyBatteryValue);
      //  mTxtVwNotifyTimeStamp = (TextView)rootView.findViewById(R.id.txtVw_NotifyBatteryTimestamp);
       // mTxtVwReadHumidityValue = (TextView)rootView.findViewById(R.id.txtVw_NotifyHumidityValue);
        mTxtVwReadPressureValue1 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue1);
        mTxtVwReadPressureValue2 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue2);
        mTxtVwReadPressureValue3 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue3);
        mTxtVwReadPressureValue4 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue4);
        mTxtVwReadPressureValue5 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue5);
        mTxtVwReadPressureValue6 = (TextView)rootView.findViewById(R.id.txtVw_NotifyPressureValue6);
        mTxtVwReadTempValue1 = (TextView)rootView.findViewById(R.id.txtVw_NotifyTempValue1);
        mTxtVwReadTempValue2 = (TextView)rootView.findViewById(R.id.txtVw_NotifyTempValue2);


        mTglBtnNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BleService service = MainActivity.sBleService;
                if (service != null) {
                    if (service.getStatus() == BluetoothProfile.STATE_CONNECTED) {
                        BluetoothGattCharacteristic ch = service.getCharacteristicByUuid(SERVICE_BATTERY, CHARA_BATTERY_LV);
                        if (ch == null) {
                            Toast.makeText(getActivity(), R.string.str_CharaNotFound, Toast.LENGTH_SHORT).show();
                            mTglBtnNotify.setChecked(false);
                        }
                        else {
                            if (((ToggleButton)v).isChecked()) {
                                mCallbacks.cbAppendLog("Enable Battery-Notification");
                                service.enableNotification(ch);
                            }
                            else {
                                mCallbacks.cbAppendLog("Disable Battery-Notification");
                                service.disableNotificationIndication(ch);
                            }
                        }
                    }
                    else {
                        mCallbacks.cbAppendLog("[FrADC]BLE Not connected");
                        mTglBtnNotify.setChecked(false);
                    }
                }
            }
        });

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();

        mTglBtnNotify.setChecked(mIsNotifyON);

        final BleService service = MainActivity.sBleService;
        if (service != null) {
            if (service.getStatus() == BluetoothProfile.STATE_CONNECTED) {
                mTglBtnNotify.setEnabled(true);
            }
            else {
                mTglBtnNotify.setEnabled(false);
            }
        }

        getActivity().registerReceiver(mBroadcastReceiver, makeIntentFilter());
    }

    @Override
    public void onPause() {
        super.onPause();

        if (mIsNotifyON) {
            BleService service = MainActivity.sBleService;
            if (service != null) {
                BluetoothGattCharacteristic ch = service.getCharacteristicByUuid(SERVICE_BATTERY, CHARA_BATTERY_LV);
                mCallbacks.cbAppendLog("Disable Battery-Notification");
                try {
                    service.disableNotificationIndication(ch);
                } catch (NullPointerException ignored) {
                }
            }
            mTglBtnNotify.setEnabled(false);
            mIsNotifyON = false;
        }

        getActivity().unregisterReceiver(mBroadcastReceiver);
    }


    private final BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @SuppressLint("DefaultLocale")
        @Override
        public void onReceive(Context context, Intent intent) {

            final String action = intent.getAction();

            switch (action) {
                case BLE_CONNECTED:
                    mCallbacks.cbAppendLog("[FrADC]BC Rx: CONNECTED");

                    break;
                case BLE_DISCONNECTED:
                    mCallbacks.cbAppendLog("[FrADC]BC Rx: DISCONNECTED");

                    mIsNotifyON = false;
                    mTglBtnNotify.setChecked(false);
                    mTglBtnNotify.setEnabled(false);
                    break;
                case BLE_DISCONNECTED_LL:
                    mCallbacks.cbAppendLog("[FrADC]BC Rx: DISCONNECTED_LL");

                    mIsNotifyON = false;
                    mTglBtnNotify.setChecked(false);
                    mTglBtnNotify.setEnabled(false);
                    break;
                case BLE_SERVICE_DISCOVERED_BAS:
                    mCallbacks.cbAppendLog("[FrADC]BC Rx: SRV_DISCOVERED_BAS");
                    mTglBtnNotify.setEnabled(true);
                    break;
                case BLE_DESC_W_BATTERY_LV:

                    String hexString = intent.getStringExtra(EXTRA_DATA);
                    byte[] bytes = BleService.hexStringToBinary(hexString);
                    if ((bytes[0] == (byte) 0x01) && (bytes[1] == (byte) 0x00)) {
                        mIsNotifyON = true;
                        mCallbacks.cbAppendLog("[FrADC]BC Rx: DESC_W_BATTERY_LV On");
                    } else {
                        mIsNotifyON = false;
                        mCallbacks.cbAppendLog("[FrADC]BC Rx: DESC_W_BATTERY_LV Off");
                    }
                    mTglBtnNotify.setChecked(mIsNotifyON);
                    break;
                case BLE_CHAR_N_BATTERY_LV:

                    String hexData = intent.getStringExtra(EXTRA_DATA);

                    String BattData=hexData.substring(0,2);
                    int Battvalue = Integer.parseInt(BattData, 16);
                    String data_batt= String.valueOf(Battvalue);

                    String TempData1=hexData.substring(2,4);
                    int Tempvalue1 = Integer.parseInt(TempData1, 16);
                    String data_temp1= String.valueOf(Tempvalue1);
                    String TempData2=hexData.substring(4,6);
                    int Tempvalue2 = Integer.parseInt(TempData2, 16);
                    String data_temp2= String.valueOf(Tempvalue2);

                    String PData1= hexData.substring(6,8);
                    int Pvalue1 = Integer.parseInt(PData1,16);
                    String data_P1 = String.valueOf(Pvalue1);
                    String PData2= hexData.substring(8,10);
                    int Pvalue2 = Integer.parseInt(PData2,16);
                    String data_P2 = String.valueOf(Pvalue2);
                    String PData3= hexData.substring(10,12);
                    int Pvalue3 = Integer.parseInt(PData3,16);
                    String data_P3 = String.valueOf(Pvalue3);
                    String PData4= hexData.substring(12,14);
                    int Pvalue4 = Integer.parseInt(PData4,16);
                    String data_P4 = String.valueOf(Pvalue4);
                    String PData5= hexData.substring(14,16);
                    int Pvalue5 = Integer.parseInt(PData5,16);
                    String data_P5 = String.valueOf(Pvalue5);
                    String PData6= hexData.substring(16,18);
                    int Pvalue6 = Integer.parseInt(PData6,16);
                    String data_P6 = String.valueOf(Pvalue6);
               //    String PressureData=hexData.substring(5,10);
               //     int Pressurevalue = Integer.parseInt(PressureData,16);
               //     String data_pressure= String.valueOf(Pressurevalue);

                //    mTxtVwReadBatteryValue.setText(hexData);
                    mTxtVwReadBatteryValue.setText(data_batt);
                    mTxtVwReadTempValue1.setText(data_temp1);
                    mTxtVwReadTempValue2.setText(data_temp2);
                    mTxtVwReadPressureValue1.setText(data_P1);
                    mTxtVwReadPressureValue2.setText(data_P2);
                    mTxtVwReadPressureValue3.setText(data_P3);
                    mTxtVwReadPressureValue4.setText(data_P4);
                    mTxtVwReadPressureValue5.setText(data_P5);
                    mTxtVwReadPressureValue6.setText(data_P6);
                //    mTxtVwReadPressureValue.setText(data_pressure);
                 //   mCallbacks.cbAppendLog("[FrADC]BC Rx: CHAR_N_BATTERY_LV  " + data + "%");

                    //mTxtVwNotifyTimeStamp.setText(String.format("%tT", new Date()));
                    break;
            }
        }
    };


    private static IntentFilter makeIntentFilter() {

        final IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(BLE_CONNECTED);
        intentFilter.addAction(BLE_DISCONNECTED);
        intentFilter.addAction(BLE_DISCONNECTED_LL);
        intentFilter.addAction(BLE_SERVICE_DISCOVERED_BAS);
        intentFilter.addAction(BLE_DESC_W_BATTERY_LV);
        intentFilter.addAction(BLE_CHAR_N_BATTERY_LV);
        return intentFilter;
    }
}

