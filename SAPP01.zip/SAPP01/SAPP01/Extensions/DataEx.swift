//
//  DataEx.swift
//  SAPP01
//
//  Created by datdn on 5/24/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import Foundation

extension NSData {
    func toHexString() -> String {
        let string = NSMutableString(capacity: length * 2)
        var byte: UInt8 = 0
        
        for i in 0 ..< length {
            getBytes(&byte, range: NSMakeRange(i, 1))
            string.appendFormat("%02x", byte)
        }
        
        return string as String
    }
}

