//
//  StringEx.swift
//  SAPP01
//
//  Created by datdn on 5/24/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import Foundation

extension String {
    subscript  (r: Range<Int>) -> String {
        get {
            let myNSString = self as NSString
            let start = r.lowerBound
            let length = r.upperBound - start + 1
            return myNSString.substring(with: NSRange(location: start, length: length))
        }
    }
}

