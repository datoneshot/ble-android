//
//  ColorEx.swift
//  SAPP01
//
//  Created by datdn on 5/25/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import Foundation

extension UIColor {
    static var tintColor: UIColor {
        get {
            return UIApplication.shared.keyWindow?.rootViewController?.view.tintColor ?? .clear
        }
    }
    
    static func rgb(red: CGFloat, green: CGFloat, blue: CGFloat) -> UIColor {
        return UIColor(red: red/255, green: green/255, blue: blue/255, alpha: 1)
    }
}
