//
//  PeripheralCell.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

class PeripheralCell: UITableViewCell {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var rssiLbl: UILabel!
    @IBOutlet weak var identifierLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func renderCellWithPeripheral(_ peripheral: DisplayPeripheral) {
        nameLbl.text = peripheral.localName ?? "Unknow"
        rssiLbl.text = peripheral.lastRSSI?.stringValue
        identifierLbl.text = peripheral.peripheral?.identifier.uuidString
    }
}
