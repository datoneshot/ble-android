//
//  MenuCell.swift
//  SAPP01
//
//  Created by datdn on 5/30/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

class MenuCell: UICollectionViewCell {
    let tabBtn: UIButton = {
        let b = UIButton()
        b.addTarget(self, action: #selector(changeTab), for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()
    
    @objc private func changeTab() {
        print("Change tab")
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    override var isHighlighted: Bool {
        didSet {
            tabBtn.tintColor = isHighlighted ? .white : .rgb(red: 91, green: 14, blue: 13)
        }
    }
    
    override var isSelected: Bool {
        didSet {
            tabBtn.tintColor = isSelected ? .white : .rgb(red: 91, green: 14, blue: 13)
        }
    }
    
    func setTabTitle(_ title: String) {
        tabBtn.setTitle(title, for: .normal)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        contentView.addSubview(tabBtn)
        NSLayoutConstraint.activate([
            tabBtn.topAnchor.constraint(equalTo: contentView.topAnchor),
            tabBtn.leftAnchor.constraint(equalTo: contentView.leftAnchor),
            tabBtn.rightAnchor.constraint(equalTo: contentView.rightAnchor),
            tabBtn.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }
}
