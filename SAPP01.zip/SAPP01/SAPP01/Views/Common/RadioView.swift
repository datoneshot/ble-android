//
//  RadioView.swift
//  SAPP01
//
//  Created by datdn on 5/25/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

class RadioView: UIView {

    var dotPadding: CGFloat = 3
    var deselectedColor: UIColor = .lightGray
    var selectedColor: UIColor = .tintColor
    var isSelected: Bool = false {
        didSet {
            isSelected ? setSelectedColor(selectedColor) : setDeselectedColor(deselectedColor)
        }
    }
    
    var dotView: UIView = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        self.layer.borderWidth = 2
        self.layer.borderColor = deselectedColor.cgColor
        self.clipsToBounds = true
        self.dotView.backgroundColor = .clear
        self.addSubview(self.dotView)
        //self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(selectedTapHandler)))
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = self.bounds.width / 2.0
        let dotWidth = self.bounds.width - (dotPadding * 2)
        self.dotView.frame = CGRect(x: dotPadding, y: dotPadding, width: dotWidth, height: dotWidth)
        self.dotView.layer.cornerRadius = dotWidth / 2.0
    }
    
    public func setBorderWidth(_ width: CGFloat) {
        self.layer.borderWidth = width
        setNeedsLayout()
        setNeedsDisplay()
    }
    
    public func setDotPadding(_ padding: CGFloat) {
        self.dotPadding = padding
        setNeedsLayout()
        setNeedsDisplay()
    }
    
    public func setDeselectedColor(_ color: UIColor) {
        self.deselectedColor = color
        self.layer.borderColor = color.cgColor
        self.dotView.isHidden = true
    }
    
    public func setSelectedColor(_ color: UIColor) {
        self.selectedColor = color
        self.layer.borderColor = color.cgColor
        self.dotView.isHidden = false
        self.dotView.backgroundColor = color
    }
    
    @objc private func selectedTapHandler() {
        isSelected = !isSelected
    }
}
