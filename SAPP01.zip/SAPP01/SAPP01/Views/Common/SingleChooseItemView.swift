//
//  SingleChooseItemView.swift
//  SAPP01
//
//  Created by datdn on 5/25/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

protocol SingleChooseItemViewDelegate: class {
    func didSelectedItem(_ item: SingleChooseItemView, at index: Int)
}

class SingleChooseItemView: UIView {
    var index: Int = 0
    weak var delegate: SingleChooseItemViewDelegate?
    
    lazy var radioView: RadioView = {
        let v = RadioView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var titleLbl: UILabel = {
        let v = UILabel()
        v.font = UIFont.systemFont(ofSize: 16)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    convenience init(title: String) {
        self.init(frame: .zero)
        titleLbl.text = title
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        self.addSubview(radioView)
        self.addSubview(titleLbl)
        
        NSLayoutConstraint.activate([
            radioView.widthAnchor.constraint(equalToConstant: 20),
            radioView.heightAnchor.constraint(equalToConstant: 20),
            radioView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8),
            radioView.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            titleLbl.centerYAnchor.constraint(equalTo: radioView.centerYAnchor, constant: 0),
            titleLbl.leftAnchor.constraint(equalTo: radioView.rightAnchor, constant: 10),
            titleLbl.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -8)
        ])
        
        self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(selectedHandler)))
    }
    
    @objc private func selectedHandler() {
        delegate?.didSelectedItem(self, at: index)
    }
    
    public func selectedItem() {
        radioView.isSelected = true
    }
    
    public func deselectedItem() {
        radioView.isSelected = false
    }
}
