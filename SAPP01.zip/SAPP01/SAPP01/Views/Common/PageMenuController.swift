//
//  PageMenuController.swift
//  SAPP01
//
//  Created by datdn on 5/30/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import Foundation
import UIKit

protocol PageMenuControllerDatasource: class {
    func numberOfControllers() -> Int
    func controllerAtIndex(_ index: Int) -> UIViewController
}

protocol PageMenuControllerDelegate: class {
}

class PageMenuCell: UICollectionViewCell {
    var controller: UIViewController!
    func addViewControllerToParentViewController(_ parentController: UIViewController) {
        parentController.addChildViewController(controller)
        self.controller.didMove(toParentViewController: parentController)
        self.contentView.addSubview(controller.view)
    }
    
    func removeViewControllerToParentViewController(_ parentController: UIViewController) {
        self.controller.view.removeFromSuperview()
        self.controller.willMove(toParentViewController: nil)
        self.controller.removeFromParentViewController()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.controller?.view.frame = self.contentView.bounds
    }
}

class PageMenuController: UIViewController {
    let cellId = "PageMenuCellId"
    weak var datasource: PageMenuControllerDatasource?
    weak var delegate: PageMenuControllerDelegate?
    
    lazy var menuBar: MenuBar = {
        let b = MenuBar()
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.scrollDirection = .horizontal
        let col = UICollectionView(frame: .zero, collectionViewLayout: layout)
        col.delegate = self
        col.dataSource = self
        col.translatesAutoresizingMaskIntoConstraints = false
        col.backgroundColor = .white
        col.register(PageMenuCell.self, forCellWithReuseIdentifier: cellId)
        col.isPagingEnabled = true
        col.showsVerticalScrollIndicator = false
        col.showsHorizontalScrollIndicator = false
        return col
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(collectionView)
        view.addSubview(menuBar)
        
        NSLayoutConstraint.activate([
            menuBar.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 0),
            menuBar.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            menuBar.rightAnchor.constraint(equalTo: view.rightAnchor, constant: 0),
            menuBar.bottomAnchor.constraint(equalTo: collectionView.topAnchor, constant: 0),
            menuBar.heightAnchor.constraint(equalToConstant: 40),
            
            collectionView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 0),
            collectionView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: 0),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0)
        ])
    }
}

extension PageMenuController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return datasource?.numberOfControllers() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let controller = datasource?.controllerAtIndex(indexPath.item)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! PageMenuCell
        cell.controller = controller
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let pageCell = cell as? PageMenuCell else { return }
        pageCell.addViewControllerToParentViewController(self)
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let pageCell = cell as? PageMenuCell else { return }
        pageCell.removeViewControllerToParentViewController(self)
    }
}

extension PageMenuController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.bounds.size
    }
}
