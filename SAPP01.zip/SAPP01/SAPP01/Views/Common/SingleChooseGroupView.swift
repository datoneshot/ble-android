//
//  SingleChooseGroupView.swift
//  SAPP01
//
//  Created by datdn on 5/25/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

protocol SingleChooseGroupViewDelegate: class {
    func selectedItem(_ item: SingleChooseItemView, at index: Int)
}

class SingleChooseGroupView: UIView {
    var selectedIndex: Int = 0
    var itemHeight: CGFloat = 25
    var itemPadding: CGFloat = 10
    
    var items = [SingleChooseItemView]()
    weak var delegate: SingleChooseGroupViewDelegate?
    
    var titles: [String] = [] {
        didSet {
            setupItems()
            invalidateIntrinsicContentSize()
        }
    }
    
    override var intrinsicContentSize: CGSize {
        let width = self.frame.width
        let items = CGFloat(titles.count)
        return CGSize(width: width, height: (items * itemHeight) + (items - 1) * itemPadding)
    }
    
    private func setupItems() {
        items = titles.map { SingleChooseItemView(title: $0) }
        items.enumerated().forEach {
            $1.translatesAutoresizingMaskIntoConstraints = false
            $1.index = $0
            $1.delegate = self
            self.addSubview($1)
        }
        setupConstraints()
        setDefaultSelectedItem()
    }
    
    private func setupConstraints() {
        var preItem: SingleChooseItemView? = nil
        for item in items {
            NSLayoutConstraint.activate([
                item.heightAnchor.constraint(equalToConstant: itemHeight),
                item.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 0),
                item.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0)
            ])
            if let preItem = preItem {
                NSLayoutConstraint.activate([
                    item.topAnchor.constraint(equalTo: preItem.bottomAnchor, constant: itemPadding)
                ])
            } else {
                NSLayoutConstraint.activate([
                    item.topAnchor.constraint(equalTo: self.topAnchor, constant: 0)
                ])
            }
            preItem = item
        }
        if let preItem = preItem {
            NSLayoutConstraint.activate([
                preItem.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
            ])
        }
    }
    
    private func setDefaultSelectedItem() {
        guard items.count > 0 else { return }
        items[0].selectedItem()
        selectedIndex = 0
        delegate?.selectedItem(items[0], at: 0)
    }
}

extension SingleChooseGroupView: SingleChooseItemViewDelegate {
    func didSelectedItem(_ item: SingleChooseItemView, at index: Int) {
        guard index != selectedIndex else { return }
        let oldSelectedItem = items[selectedIndex]
        let newSelectedItem = item
        oldSelectedItem.deselectedItem()
        newSelectedItem.selectedItem()
        selectedIndex = index
        delegate?.selectedItem(newSelectedItem, at: selectedIndex)
    }
}
