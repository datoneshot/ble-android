//
//  Constant.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import Foundation

struct SAPPServices {
    // MARK: Generic Access Profile(GA) - 0x1800
    public static let SERVICE_GENERIC_ACCESS                = "00001800-0000-1000-8000-00805f9b34fb"
    
    // MARK: Device Info Service(DI) - 0x180A
    public static let  SERVICE_DEVICE_INFO                  = "0000180a-0000-1000-8000-00805f9b34fb"
    
    // MARK: Battery Service(BAS) - 0x180F
    public static let SERVICE_BATTERY                       = "0000180f-0000-1000-8000-00805f9b34fb"
    
    public static let SERVICE_GENERIC_ACCESS_UUID           = "1800"
    public static let SERVICE_DEVICE_INFO_UUID              = "180A"
    public static let SERVICE_BATTERY_UUID                  = "180F"
    
    // MARK: Original Service(SOS)
    public static let  SERVICE_SAPPHIRE_ORIGINAL            = "00005453-4220-7479-7065-204100000001"
}

struct SAPPCharacteristics {
    // MARK: Generic Access Profile(GA) - 0x1800
    public static let CHARA_DEVICE_NAME                     = "00002a00-0000-1000-8000-00805f9b34fb"
    public static let CHARA_APPEARANCE                      = "00002a01-0000-1000-8000-00805f9b34fb"
    
    // MARK: Device Info Service(DI) - 0x180A
    public static let  CHARA_HARDWARE_REV                   = "00002a27-0000-1000-8000-00805f9b34fb"
    public static let  CHARA_SOFTWARE_REV                   = "00002a28-0000-1000-8000-00805f9b34fb"
    public static let  CHARA_FIRMWARE_REV                   = "00002a26-0000-1000-8000-00805f9b34fb"
    public static let  CHARA_MANUFACTURE_NAME               = "00002a29-0000-1000-8000-00805f9b34fb"
    public static let  CHARA_HARDWARE_REV_UUID              = "2A27"
    public static let  CHARA_SOFTWARE_REV_UUID              = "2A28"
    public static let  CHARA_FIRMWARE_REV_UUID              = "2A26"
    public static let  CHARA_MANUFACTURE_NAME_UUID          = "2A29"
    
    // MARK: Battery Service(BAS) - 0x180F
    public static let CHARA_BATTERY_LV                      = "00002a19-0000-1000-8000-00805f9b34fb"
    public static let CHARA_BATTERY_LV_UUID                 = "2A19"
    
    
    
    // MARK: Original Service(SOS)
    public static let  CHARA_CONSOLE                        = "00005453-4220-7479-7065-204100000301"
}
