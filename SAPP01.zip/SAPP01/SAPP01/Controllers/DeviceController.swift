//
//  DeviceController.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit
import CoreBluetooth

class DeviceController: UIViewController {
    var currentPeripheral: CBPeripheral!
    var discoveryManager = BLEDeviceDiscoverServices()
    var propertyManager = BLEDeviceProperties()
    
    // MARK: Labels
    @IBOutlet weak var devNameLbl: UILabel!
    @IBOutlet weak var appearLbl: UILabel!
    @IBOutlet weak var swRevLbl: UILabel!
    @IBOutlet weak var fwRevLbl: UILabel!
    @IBOutlet weak var hwRevLbl: UILabel!
    @IBOutlet weak var mfNameLbl: UILabel!
    
    // MARK: Buttons
    @IBOutlet weak var rdDevBtn: UIButton!
    @IBOutlet weak var rdAppearBtn: UIButton!
    @IBOutlet weak var rdSwRevBtn: UIButton!
    @IBOutlet weak var rdFwRevBtn: UIButton!
    @IBOutlet weak var rdHwRevBtn: UIButton!
    @IBOutlet weak var rdMfNameBtn: UIButton!
    
    var services: NSArray?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let currentPeripheral = currentPeripheral else { return }
        discoverServices(peripheral: currentPeripheral)
    }
    
    //Discover all the services of the connected device
    private func discoverServices(peripheral: CBPeripheral) {
        discoveryManager.delegate = self
        guard let peripheral = currentPeripheral else { return }
        discoveryManager.discoverAllServices(peripheral: peripheral)
    }
    
    // MARK: Actions
    @IBAction func rdDevNameHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverAllCharacteristics(peripheral: peripheral, service: service)
    }
    
    @IBAction func rdAppearHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_BATTERY_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverAllCharacteristics(peripheral: peripheral, service: service)
    }
    
    @IBAction func rdSwRevHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverCharacteristicsByUUIDs(charUUIds: [CBUUID(string: SAPPCharacteristics.CHARA_SOFTWARE_REV)], peripheral: peripheral, service: service)
    }
    
    @IBAction func rdFwRevHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverCharacteristicsByUUIDs(charUUIds: [CBUUID(string: SAPPCharacteristics.CHARA_FIRMWARE_REV)], peripheral: peripheral, service: service)
    }
    
    @IBAction func rdHwRevHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverCharacteristicsByUUIDs(charUUIds: [CBUUID(string: SAPPCharacteristics.CHARA_HARDWARE_REV)], peripheral: peripheral, service: service)
    }
    
    @IBAction func rdMfNameHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let service = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) else { return }
        discoveryManager.delegate = self
        discoveryManager.discoverCharacteristicsByUUIDs(charUUIds: [CBUUID(string: SAPPCharacteristics.CHARA_MANUFACTURE_NAME)], peripheral: peripheral, service: service)
    }
    
    private func getServiceByUUID(_ uuid: String) -> CBService? {
        guard let services = services as? [CBService] else { return nil }
        for service in services {
            if service.uuid.uuidString == uuid {
                return service
            }
        }
        return nil
    }

    
    private func enableDisableButtons(_ buttons: [UIButton], status: Bool) {
        buttons.forEach { $0.isEnabled = status }
    }
    
    private func readCharacteristicesValue(_ characteristices: CBCharacteristic) {
        guard let peripheral = currentPeripheral else { return }
        propertyManager.delegate = self
        propertyManager.readCharacteristicValue(peripheral: peripheral, char: characteristices)
    }
    
    
}

extension DeviceController: DiscoveryDelegate {
    func postDicoverdServiceFailed(error: NSError?) {
        enableDisableButtons([rdDevBtn, rdAppearBtn, rdSwRevBtn, rdFwRevBtn, rdHwRevBtn, rdMfNameBtn], status: false)
    }
    
    func postDiscoveredServices(discoveredServices: NSArray) {
        print("postDiscoveredServices: \(discoveredServices)")
        services = discoveredServices
        let enableGenericStatus = getServiceByUUID(SAPPServices.SERVICE_GENERIC_ACCESS_UUID) != nil
        enableDisableButtons([rdDevBtn, rdAppearBtn], status: enableGenericStatus)
        let enableDevInfoStatus = getServiceByUUID(SAPPServices.SERVICE_DEVICE_INFO_UUID) != nil
        enableDisableButtons([rdSwRevBtn, rdFwRevBtn, rdHwRevBtn, rdMfNameBtn], status: enableDevInfoStatus)
    }
    
    func postDiscoverdCharacteristices(discoveredCharacteristics: NSArray) {
        print("postDiscoverdCharacteristices: \(discoveredCharacteristics)")
        guard let charac = discoveredCharacteristics.lastObject as? CBCharacteristic else { return }
        if charac.uuid.uuidString == SAPPCharacteristics.CHARA_HARDWARE_REV_UUID {
            readCharacteristicesValue(charac)
        } else if charac.uuid.uuidString == SAPPCharacteristics.CHARA_SOFTWARE_REV_UUID {
            readCharacteristicesValue(charac)
        } else if charac.uuid.uuidString == SAPPCharacteristics.CHARA_FIRMWARE_REV_UUID {
            readCharacteristicesValue(charac)
        } else if charac.uuid.uuidString == SAPPCharacteristics.CHARA_MANUFACTURE_NAME_UUID {
            readCharacteristicesValue(charac)
        }
    }
    
    func PostDicoverdCharacteristicesFailed(error: NSError?) {
        print("PostDicoverdCharacteristicesFailed: \(error)")
    }
}

extension DeviceController: PropertiesDelegate {
    func postReadCharacteristicValue(peripheral: CBPeripheral, char: CBCharacteristic) {
        guard let data = char.value else { return }
        let text = String(data: data, encoding: .ascii)
        if char.uuid.uuidString == SAPPCharacteristics.CHARA_SOFTWARE_REV_UUID {
            swRevLbl.text = text ?? "---"
        } else if char.uuid.uuidString == SAPPCharacteristics.CHARA_HARDWARE_REV_UUID {
            hwRevLbl.text = text ?? "---"
        } else if char.uuid.uuidString == SAPPCharacteristics.CHARA_FIRMWARE_REV_UUID {
            fwRevLbl.text = text ?? "---"
        } else if char.uuid.uuidString == SAPPCharacteristics.CHARA_MANUFACTURE_NAME_UUID {
           mfNameLbl.text = text ?? "---"
        }
    }
}
