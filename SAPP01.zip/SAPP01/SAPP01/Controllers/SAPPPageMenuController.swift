//
//  SAPPPageMenuController.swift
//  SAPP01
//
//  Created by datdn on 5/30/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

class SAPPPageMenuController: PageMenuController {
    var controllers: [UIViewController]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        controllers = ["ScanControllerId", "DeviceControllerId", "ADCControllerId", "ConsoleControllerId"]
            .flatMap { self.storyboard?.instantiateViewController(withIdentifier: $0) }
        menuBar.titles = ["BLE", "Device Info", "ADC", "Console"]
        menuBar.backgroundColor = UIColor.rgb(red: 0, green: 87, blue: 227)
        self.delegate = self
        self.datasource = self
    }
}

extension SAPPPageMenuController: PageMenuControllerDatasource {
    func numberOfControllers() -> Int {
        return controllers?.count ?? 0
    }
    
    func controllerAtIndex(_ index: Int) -> UIViewController {
        return controllers[index]
    }
}

extension SAPPPageMenuController: PageMenuControllerDelegate {
    
}
