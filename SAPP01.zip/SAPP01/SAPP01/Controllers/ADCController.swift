//
//  ADCController.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit
import CoreBluetooth

class ADCController: UIViewController {
    @IBOutlet weak var notiBtn: UIButton!
    @IBOutlet weak var humiLbl: UILabel!
    @IBOutlet weak var temLbl: UILabel!
    @IBOutlet weak var presLbl: UILabel!
    
    var characteristics: CBCharacteristic?
    
    var currentPeripheral: CBPeripheral!
    var discoveryManager = BLEDeviceDiscoverServices()
    var propertyManager = BLEDeviceProperties()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let currentPeripheral = currentPeripheral else { return }
        discoverServices(peripheral: currentPeripheral)
    }
    
    //Discover all the services of the connected device
    private func discoverServices(peripheral: CBPeripheral) {
        discoveryManager.delegate = self
        guard let peripheral = currentPeripheral else { return }
        discoveryManager.discoverServiceByUUIDs(servicesUUIDs: [CBUUID(string: SAPPServices.SERVICE_BATTERY)], peripheral: peripheral)
    }

    @IBAction func notiHandler(_ sender: UIButton) {
        guard let characteristics = characteristics, let peripheral = currentPeripheral else { return }
        propertyManager.delegate = self
        propertyManager.setNotifyValue(peripheral: peripheral, enabled: true, char: characteristics)
    }
    
    private func getHumidityFromHexString(_ hex: String) -> String {
        let humHex = hex[0..<1]
        let humNumBase16 = Int(humHex, radix: 16)
        return humNumBase16 != nil ? "\(humNumBase16!)" : "---"
    }
    
    private func getTemperatureFromHexString(_ hex: String) -> String {
        let tem1Hex = hex[2..<3]
        let tem1HexBase16 = Int(tem1Hex, radix: 16)
        let tem2Hex = hex[4..<5]
        let tem2HexBase16 = Int(tem2Hex, radix: 16)
        return "\(tem1HexBase16!).\(tem2HexBase16!)"
    }
    
    private func getPressureFromHexString(_ hex: String) -> String {
        let press1Hex = hex[6..<7]
        let press1HexBase16 = Int(press1Hex, radix: 16)
        
        let press2Hex = hex[8..<9]
        let press2HexBase16 = Int(press2Hex, radix: 16)
        
        let press3Hex = hex[10..<11]
        let press3HexBase16 = Int(press3Hex, radix: 16)
        
        let press4Hex = hex[12..<13]
        let press4HexBase16 = Int(press4Hex, radix: 16)
        
        let press5Hex = hex[14..<15]
        let press5HexBase16 = Int(press5Hex, radix: 16)
        
        let press6Hex = hex[16..<17]
        let press6HexBase16 = Int(press6Hex, radix: 16)
        
        return "\(press1HexBase16!)\(press2HexBase16!)\(press3HexBase16!)\(press4HexBase16!)\(press5HexBase16!)\(press6HexBase16!)"
    }
}

extension ADCController: DiscoveryDelegate {
    func postDicoverdServiceFailed(error: NSError?) {
        notiBtn.isEnabled = false
    }
    
    func postDiscoveredServices(discoveredServices: NSArray) {
        print("postDiscoveredServices: \(discoveredServices)")
        for service in discoveredServices {
            if let service = service as? CBService {
                if service.uuid.uuidString == SAPPServices.SERVICE_BATTERY_UUID {
                    discoveryManager.discoverAllCharacteristics(peripheral: currentPeripheral, service: service)
                }
            }
        }
    }
    
    func postDiscoverdCharacteristices(discoveredCharacteristics: NSArray) {
        print("postDiscoverdCharacteristices: \(discoveredCharacteristics)")
        for charac in discoveredCharacteristics {
            if let charac = charac as? CBCharacteristic, charac.uuid.uuidString == SAPPCharacteristics.CHARA_BATTERY_LV_UUID {
                 notiBtn.isEnabled = true
                characteristics = charac
            }
        }
    }
    
    func PostDicoverdCharacteristicesFailed(error: NSError?) {
        notiBtn.isEnabled = false
        print("PostDicoverdCharacteristicesFailed: \(error)")
    }
}

extension ADCController: PropertiesDelegate {
    func postNotifyValueUpdate(peripheral: CBPeripheral, char: CBCharacteristic) {
    }
    
    func postReadCharacteristicValue(peripheral: CBPeripheral, char: CBCharacteristic) {
        guard let data = char.value else { return }
        let hexString = (data as NSData).toHexString()
        print(hexString)
        let humTxt = getHumidityFromHexString(hexString)
        humiLbl.text = humTxt
        let temTxt = getTemperatureFromHexString(hexString)
        temLbl.text = temTxt
        let pressTxt = getPressureFromHexString(hexString)
        presLbl.text = pressTxt
    }
}


