//
//  SAPPPageController.swift
//  SAPP01
//
//  Created by datdn on 5/30/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit

class SAPPRootController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}


