//
//  ViewController.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit
import CoreBluetooth

class ScanController: UIViewController {
    @IBOutlet weak var scanBtn: UIButton!
    @IBOutlet weak var boundDeviceBtn: UIButton!
    @IBOutlet weak var disconnectBtn: UIButton!
    @IBOutlet weak var peripheralsTv: UITableView!
    
    @IBOutlet weak var conNameLbl: UILabel!
    @IBOutlet weak var conIdentifierLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(origin: .zero, size: CGSize(width: 20, height: 20)))
    var connectedPeripheral: CBPeripheral?
    var scanController = BLEDeviceScan()
    var pairController = BLEDeviceConnection()
    var sameDevice: Bool? = false
    var deviceArray: NSArray?
    
    var isScanning: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
    }
    
    private func setupNavigationBar() {
        let indicatorItem = UIBarButtonItem(customView: activityIndicator)
        navigationItem.rightBarButtonItem = indicatorItem
        activityIndicator.startAnimating()
        navigationItem.title = "Scan Peripherals"
    }
    
    private func initViews() {
        disconnectBtn.isEnabled = false
        changeScanButtonTitle("Scan:\nStoped")
    }
    
    private func startScan() {
        isScanning = true
        activityIndicator.startAnimating()
        scanController.delegate = self
        scanController.scanDeviceByServiceUUID(serviceUUIDs: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        peripheralsTv.reloadData()
    }
    
    private func stopScan() {
        scanController.stopScan()
    }
    
    private func changeScanButtonTitle(_ title: String) {
        scanBtn.titleLabel?.lineBreakMode = .byWordWrapping
        scanBtn.titleLabel?.textAlignment = .center
        scanBtn.setTitle(title, for: .normal)
    }
    
    @IBAction func scanHandler(_ sender: UIButton) {
        if isScanning {
            stopScan()
            changeScanButtonTitle("Scan:\nStoped")
        } else {
            deviceArray = nil
            changeScanButtonTitle("Scan:\nScanning")
            startScan()
        }
    }
    
    @IBAction func boundDeviceHandler(_ sender: UIButton) {
        
    }
    
    
    @IBAction func disconnectHandler(_ sender: UIButton) {
        disconnectBtn.isEnabled = false
        guard let connectedPeripheral = connectedPeripheral else { return }
        pairController.disConnectScannedDevice(peripheral: connectedPeripheral)
    }
}

extension ScanController: DeviceScannedDelegate {
    func postBLEConnectionStatus(status: Int) {
        if (status == Int(4)) || (status == Int(5)) {
            startScan()
        }
    }
    
    func postScannedDevices(scannedDevices: NSArray) {
        deviceArray = NSArray(array: scannedDevices)
        if deviceArray != nil && (deviceArray?.count)! > 0 {
            peripheralsTv.reloadData()
        }
    }
}

extension ScanController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return deviceArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScanCellId") as! PeripheralCell
        if let peripheral = deviceArray?.object(at: indexPath.row) as? DisplayPeripheral {
            cell.renderCellWithPeripheral(peripheral)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let pairedPeripheral = deviceArray?.object(at: indexPath.row) as? DisplayPeripheral
        let selectedPeripheral = (pairedPeripheral?.peripheral!)! as CBPeripheral
        pairController.delegate = self
        let alertVC = UIAlertController(title: nil, message: "Would you like connect to \(pairedPeripheral?.localName ?? "Unknow")?", preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        alertVC.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
            if selectedPeripheral.state.rawValue == 0 {
                if self.connectedPeripheral != nil {
                    self.pairController.disConnectScannedDevice(peripheral: self.connectedPeripheral!)
                }
                SVProgressHUD.show()
                self.pairController.connectScannedDevice(peripheral: selectedPeripheral, options: nil)
            } else if selectedPeripheral.state.rawValue == 1 {
                SVProgressHUD.show()
                self.pairController.connectScannedDevice(peripheral: selectedPeripheral, options: nil)
            } else if selectedPeripheral.state.rawValue == 2 {
                self.pairController.disConnectScannedDevice(peripheral: selectedPeripheral)
            }
        }))
        present(alertVC, animated: true , completion: nil)
    }
}

extension ScanController: PairUnPairDeviceDelegate {
    func devicePairedSuccessfully(peripheral: CBPeripheral) {
        conNameLbl.text = peripheral.name
        conIdentifierLbl.text = peripheral.identifier.uuidString
        statusLbl.text = "Connected"
        disconnectBtn.isEnabled = true
        SVProgressHUD.dismiss()
    }
    
    func devicePairedFailed(peripheral: CBPeripheral, error: Error?) {
        SVProgressHUD.dismiss()
        let alertVC = UIAlertController(title: nil, message: "Connect to device failure!", preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertVC, animated: true , completion: nil)
    }
    
    func deviceUnpairedSuccessfully(peripheral: CBPeripheral, error: Error?) {
        conNameLbl.text = nil
        conIdentifierLbl.text = nil
        statusLbl.text = "Choose a device to connect"
        disconnectBtn.isEnabled = false
        changeScanButtonTitle("Scan:\nStoped")
    }
}

