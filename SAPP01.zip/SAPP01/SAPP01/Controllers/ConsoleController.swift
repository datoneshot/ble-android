//
//  ConsoleController.swift
//  SAPP01
//
//  Created by datdn on 5/23/18.
//  Copyright © 2018 datdn. All rights reserved.
//

import UIKit
import CoreBluetooth

class ConsoleController: UIViewController {
    @IBOutlet weak var grMessageVw: SingleChooseGroupView!
    @IBOutlet weak var sendMesBtn: UIButton!
    @IBOutlet weak var mesInpTf: UITextField!
    @IBOutlet weak var ackLbl: UILabel!
    
    var characteristics: CBCharacteristic?
    var currentPeripheral: CBPeripheral!
    var discoveryManager = BLEDeviceDiscoverServices()
    var propertyManager = BLEDeviceProperties()
    var message: String?
    let messages = ["Hello, world!", "123 ABC abc #$%", "Toshiba", "Message in the input field"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        guard let currentPeripheral = currentPeripheral else { return }
        discoverServices(peripheral: currentPeripheral)
    }
    
    //Discover all the services of the connected device
    private func discoverServices(peripheral: CBPeripheral) {
        discoveryManager.delegate = self
        guard let peripheral = currentPeripheral else { return }
        discoveryManager.discoverServiceByUUIDs(servicesUUIDs: [CBUUID(string: SAPPServices.SERVICE_SAPPHIRE_ORIGINAL)], peripheral: peripheral)
    }
    
    private func setupViews() {
        grMessageVw.translatesAutoresizingMaskIntoConstraints = false
        grMessageVw.delegate = self
        grMessageVw.titles = messages
        sendMesBtn.isEnabled = false
        mesInpTf.delegate = self
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard)))
    }
    
    @IBAction func sendMessHandler(_ sender: UIButton) {
        guard let peripheral = currentPeripheral, let characteristics = characteristics else { return }
        if grMessageVw.selectedIndex == 3 {
            message = mesInpTf.text
        }
        guard let message = message, let data = message.data(using: .ascii)  else { return }
        sendMesBtn.isEnabled = false
        propertyManager.delegate = self
        ackLbl.text = "sending..."
        propertyManager.writeCharacteristicValue(peripheral: peripheral, data: data, char: characteristics, type: .withResponse)
    }
    
    @objc private func dismissKeyboard() {
        mesInpTf.resignFirstResponder()
    }
    
}

extension ConsoleController: DiscoveryDelegate {
    func postDicoverdServiceFailed(error: NSError?) {
        sendMesBtn.isEnabled = false
    }
    
    func postDiscoveredServices(discoveredServices: NSArray) {
        print("postDiscoveredServices: \(discoveredServices)")
        for service in discoveredServices {
            if let service = service as? CBService {
                if service.uuid.uuidString == SAPPServices.SERVICE_SAPPHIRE_ORIGINAL {
                    discoveryManager.discoverAllCharacteristics(peripheral: currentPeripheral, service: service)
                }
            }
        }
    }
    
    func postDiscoverdCharacteristices(discoveredCharacteristics: NSArray) {
        print("postDiscoverdCharacteristices: \(discoveredCharacteristics)")
        for charac in discoveredCharacteristics {
            if let charac = charac as? CBCharacteristic, charac.uuid.uuidString == SAPPCharacteristics.CHARA_CONSOLE {
                characteristics = charac
                sendMesBtn.isEnabled = true
            }
        }
    }
    
    func PostDicoverdCharacteristicesFailed(error: NSError?) {
        print("PostDicoverdCharacteristicesFailed: \(error)")
        sendMesBtn.isEnabled = false
    }
}

extension ConsoleController: PropertiesDelegate {
    func postWriteCharacteristicValue(peripheral: CBPeripheral, char: CBCharacteristic) {
        sendMesBtn.isEnabled = true
        ackLbl.text = message
    }
    
    func postWriteCharacteristicValueFailed(error: Error?) {
        sendMesBtn.isEnabled = true
        ackLbl.text = "---"
    }
}

extension ConsoleController: SingleChooseGroupViewDelegate {
    func selectedItem(_ item: SingleChooseItemView, at index: Int) {
        message = messages[index]
        if index == 3 {
            mesInpTf.becomeFirstResponder()
        }
    }
}

extension ConsoleController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        mesInpTf.resignFirstResponder()
        return true
    }
}
